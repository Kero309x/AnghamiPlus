package com.kero.anghamify.hooks.sections;

import com.kero.anghamify.hooks.core.BoolHook;
import com.kero.anghamify.hooks.core.HookSection;
import com.kero.anghamify.hooks.core.Logger;

import de.robv.android.xposed.XC_MethodReplacement;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public final class AdHooks implements HookSection {
    @Override public String getSectionName() { return "Ad Blocker"; }

    @Override
    public boolean install(XC_LoadPackage.LoadPackageParam lpparam) {
        String[][] methods = new String[][]{
                {"com.anghami.ghost.objectbox.models.ads.AdSettings", "isAudiobookAdsDisabled"},
                {"com.anghami.ghost.objectbox.models.ads.AdSettings", "isPodcastAdsDisabled"},
        };

        int hit = 0;
        for (String[] m : methods) if (BoolHook.hook(lpparam, m[0], m[1], true)) hit++;
        Logger.i("  └─ " + hit + "/" + methods.length + " hooks successful");

        // ✅ Hook popup method
        try {
            XposedHelpers.findAndHookMethod(
                    "com.anghami.ui.popupwindow.A",
                    lpparam.classLoader,
                    "i",
                    "com.anghami.ui.popupwindow.a",
                    XC_MethodReplacement.returnConstant(null)
            );
            Logger.i("  └─ Popup hook applied successfully");
        } catch (Throwable t) {
            Logger.e("  └─ Popup hook failed", t);
        }

        return hit > 0;
    }
}