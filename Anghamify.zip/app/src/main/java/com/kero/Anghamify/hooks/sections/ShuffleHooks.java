package com.kero.anghamify.hooks.sections;

import com.kero.anghamify.hooks.core.ClassUtils;
import com.kero.anghamify.hooks.core.HookSection;
import com.kero.anghamify.hooks.core.Logger;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XC_MethodReplacement;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public final class ShuffleHooks implements HookSection {

    @Override public String getSectionName() { return "Shuffle Control"; }

    @Override
    public boolean install(XC_LoadPackage.LoadPackageParam lpparam) {
        int hooked = 0;

        try {
            Class<?> modelClass = ClassUtils.findClassSafely(
                    "com.anghami.ghost.pojo.PossiblyGenericModel",
                    lpparam.classLoader
            );

            if (modelClass == null) {
                Logger.i("  └─ ⚠️ PossiblyGenericModel not found");
                return false;
            }

            // 1) Force field isShuffleMode = false at all times
            try {
                XposedBridge.hookAllMethods(modelClass, "getShuffleMode", new XC_MethodReplacement() {
                    @Override protected Object replaceHookedMethod(MethodHookParam param) {
                        return false;
                    }
                });
                hooked++;
            } catch (Throwable ignored) {}

            // Freeze field whenever object is created
            try {
                XposedBridge.hookAllConstructors(modelClass, new XC_MethodHook() {
                    @Override protected void afterHookedMethod(MethodHookParam param) {
                        try {
                            XposedHelpers.setBooleanField(param.thisObject, "isShuffleMode", false);
                        } catch (Throwable ignored) {}
                    }
                });
                hooked++;
            } catch (Throwable e) {
                Logger.d("Constructor hook failed: " + e.getMessage());
            }

            // 2) Override any setter that tries to change shuffle mode
            try {
                XposedHelpers.findAndHookMethod(
                        modelClass,
                        "setShuffleMode",
                        boolean.class,
                        new XC_MethodReplacement() {
                            @Override protected Object replaceHookedMethod(MethodHookParam param) {
                                // Force value to remain false
                                try {
                                    XposedHelpers.setBooleanField(param.thisObject, "isShuffleMode", false);
                                } catch (Throwable ignored) {}
                                return null;
                            }
                        }
                );
                hooked++;
            } catch (Throwable e) {
                Logger.d("setShuffleMode not found: " + e.getMessage());
            }

            // 3) Direct field patch (if accessed directly, skip setter/getter)
            try {
                Object[] fields = modelClass.getDeclaredFields();
                for (java.lang.reflect.Field f : modelClass.getDeclaredFields()) {
                    if (f.getName().equals("isShuffleMode")) {
                        f.setAccessible(true);
                        Logger.i("  └─ Field hook: isShuffleMode found");
                    }
                }
            } catch (Throwable ignored) {}

            Logger.i("  └─ " + hooked + "/3 hooks successful");
            return hooked > 0;

        } catch (Throwable t) {
            Logger.i("  └─ ⚠️ Failed: " + t.getMessage());
            return false;
        }
    }
}